#!/bin/bash

# Exit on error
set -e

# Base directory
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

# Check for .env file
if [ ! -f .env ]; then
    echo "⚠️  .env file not found. Copying from .env.template..."
    cp .env.template .env
    echo "⚠️  Please update the GROQ_API_KEY in the newly created .env file before running."
fi

# Detect virtual environment
if [ -d .venv ]; then
    echo "💡 Using local virtual environment (.venv)..."
    source .venv/bin/activate
elif [ -d venv ]; then
    echo "💡 Using local virtual environment (venv)..."
    source venv/bin/activate
fi

# Check for chainlit
if ! command -v chainlit &> /dev/null; then
    echo "⚠️  Chainlit is not installed in the current environment."
    echo "👉 Please run: pip install -r requirements.txt"
    exit 1
fi

echo "🚀 Starting AI Coding System Chainlit server..."
chainlit run ai_system/app.py
