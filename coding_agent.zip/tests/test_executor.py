import pytest
import os
import tempfile
from pathlib import Path
from ai_system.executor.runner import ExecutionRunner

def test_execution_runner_success():
    with tempfile.TemporaryDirectory() as tmp_dir:
        runner = ExecutionRunner(workspace_dir=tmp_dir)
        # Run a simple echo command
        result = runner.execute("echo 'Hello World'")
        assert result.is_success
        assert result.returncode == 0
        assert "Hello World" in result.stdout
        assert result.stderr == ""

def test_execution_runner_failure():
    with tempfile.TemporaryDirectory() as tmp_dir:
        runner = ExecutionRunner(workspace_dir=tmp_dir)
        # Run an invalid command
        result = runner.execute("non_existent_command_12345")
        assert not result.is_success
        assert result.returncode != 0
        assert "non_existent_command_12345" in result.stderr or result.stdout == ""

def test_execution_runner_timeout():
    with tempfile.TemporaryDirectory() as tmp_dir:
        runner = ExecutionRunner(workspace_dir=tmp_dir)
        # Sleep command with a tiny timeout
        result = runner.execute("sleep 5", timeout=0.1)
        assert not result.is_success
        assert result.returncode == -1
        assert "timed out" in result.stderr

def test_execution_runner_env_sanitization():
    with tempfile.TemporaryDirectory() as tmp_dir:
        runner = ExecutionRunner(workspace_dir=tmp_dir)
        
        # Temporarily inject a sensitive key into current process environment
        os.environ["GROQ_API_KEY"] = "super-secret-key"
        try:
            # Under Unix/Mac, env command lists current environment variables
            result = runner.execute("env")
            assert result.is_success
            # Sensitive key should not be in the output of the executed process
            assert "GROQ_API_KEY" not in result.stdout
        finally:
            del os.environ["GROQ_API_KEY"]
