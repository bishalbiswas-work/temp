import pytest
from ai_system.task_manager.manager import TaskManager, Task, TaskStatus

def test_task_manager_basic_flow():
    manager = TaskManager()
    
    task1 = Task("task_1", "Task 1", "Description 1")
    task2 = Task("task_2", "Task 2", "Description 2", dependencies=["task_1"])
    
    manager.add_task(task1)
    manager.add_task(task2)
    
    # Initially, task1 should be READY (no deps) and task2 should be PENDING
    assert task1.status == TaskStatus.PENDING
    
    # Getting the next ready task will trigger update_ready_states
    next_task = manager.get_next_ready_task()
    assert next_task is not None
    assert next_task.id == "task_1"
    assert next_task.status == TaskStatus.READY
    
    # Task 2 should still be Pending
    assert manager.get_task("task_2").status == TaskStatus.PENDING
    
    # Mark Task 1 as IN_PROGRESS then COMPLETED
    manager.update_task_status("task_1", TaskStatus.IN_PROGRESS)
    assert manager.get_next_ready_task() is None  # no tasks are ready since task1 is in progress and task2 depends on task1
    
    manager.update_task_status("task_1", TaskStatus.COMPLETED)
    
    # Now task2 should be READY
    next_task = manager.get_next_ready_task()
    assert next_task is not None
    assert next_task.id == "task_2"
    assert next_task.status == TaskStatus.READY
    
    # Mark Task 2 COMPLETED
    manager.update_task_status("task_2", TaskStatus.COMPLETED)
    
    assert manager.is_all_completed()
    assert not manager.has_failures()

def test_task_manager_failures_and_retry():
    manager = TaskManager()
    task = Task("task_1", "Task 1", "Description 1")
    manager.add_task(task)
    
    # Next ready task
    t = manager.get_next_ready_task()
    assert t.id == "task_1"
    
    # Simulate execution failure
    manager.reset_failed_task_for_retry("task_1", "Compilation failed")
    
    assert task.status == TaskStatus.REPLANNED
    assert task.retry_count == 1
    assert "Compilation failed" in task.error_feedback
    assert len(task.logs) == 1
