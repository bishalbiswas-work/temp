import pytest
from ai_system.agents.base import BaseAgent

class MockAgent(BaseAgent):
    def __init__(self):
        # We don't initialize the LLM for mock tests that only test parsing logic
        self.system_prompt = "Mock prompt"

def test_base_agent_json_parsing_direct():
    agent = MockAgent()
    json_str = '{"status": "success", "count": 5}'
    result = agent._parse_json_from_response(json_str)
    assert result == {"status": "success", "count": 5}

def test_base_agent_json_parsing_markdown():
    agent = MockAgent()
    json_str = """
Here is the requested output:
```json
{
  "key": "value",
  "items": [1, 2, 3]
}
```
Hope this helps!
"""
    result = agent._parse_json_from_response(json_str)
    assert result == {"key": "value", "items": [1, 2, 3]}

def test_base_agent_json_parsing_braces():
    agent = MockAgent()
    json_str = """
Some raw text before {
  "number": 42
} and some text after.
"""
    result = agent._parse_json_from_response(json_str)
    assert result == {"number": 42}

def test_base_agent_json_parsing_invalid():
    agent = MockAgent()
    invalid_str = "This is not json at all."
    with pytest.raises(ValueError) as excinfo:
        agent._parse_json_from_response(invalid_str)
    assert "Could not parse valid JSON" in str(excinfo.value)

def test_get_llm_routing_to_zai(monkeypatch):
    monkeypatch.setenv("ZAI_API_KEY", "7eb34f2d4efa49308b1a0fd1689ba532.02ST17Ud2txjz41A")
    from ai_system.config import get_llm, ChatZai
    
    llm = get_llm(model_name="glm-4.7-flash")
    assert isinstance(llm, ChatZai)
    assert llm.model_name == "glm-4.7-flash"
    assert llm.api_key == "7eb34f2d4efa49308b1a0fd1689ba532.02ST17Ud2txjz41A"

def test_zai_integration():
    import os
    api_key = os.getenv("ZAI_API_KEY") or "7eb34f2d4efa49308b1a0fd1689ba532.02ST17Ud2txjz41A"
    
    from ai_system.config import ChatZai
    from langchain_core.messages import HumanMessage
    
    chat = ChatZai(api_key=api_key, model_name="glm-4.7-flash")
    response = chat.invoke([HumanMessage(content="Hello, respond with exactly 'ZAI WORKED' and nothing else.")])
    print("\n--- Live Z.AI Response ---")
    print(response.content)
    print("--------------------------")
    assert "ZAI WORKED" in response.content.upper()
