import os
import sys
import asyncio
import logging
import traceback
from pathlib import Path
from typing import Dict, Any, List
import chainlit as cl

# Patch Chainlit's local_steps ContextVar to prevent harmless startup LookupErrors
try:
    import chainlit.context
    class SafeContextVar:
        def __init__(self, original_var):
            self._var = original_var
            self.name = getattr(original_var, "name", "local_steps")

        def get(self, default=None):
            try:
                return self._var.get()
            except LookupError:
                return default if default is not None else []

        def set(self, value):
            return self._var.set(value)

        def reset(self, token):
            return self._var.reset(token)

    if hasattr(chainlit.context, "local_steps"):
        chainlit.context.local_steps = SafeContextVar(chainlit.context.local_steps)
    import chainlit.step
    if hasattr(chainlit.step, "local_steps"):
        chainlit.step.local_steps = chainlit.context.local_steps
    import chainlit.message
    if hasattr(chainlit.message, "local_steps"):
        chainlit.message.local_steps = chainlit.context.local_steps
except Exception:
    pass


# Setup logging to stdout
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("AICodingSystem")

# Add root folder to python path to avoid import errors when running chainlit
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ai_system.config import GENERATED_PROJECT_DIR
from ai_system.agents import (
    RequirementAgent,
    PlannerAgent,
    WriterAgent,
    ReviewerAgent,
    ValidationAgent,
    ReplannerAgent,
    PromptCondenserAgent,
)
from ai_system.task_manager.manager import TaskManager, Task, TaskStatus
from ai_system.executor.runner import ExecutionRunner


def ensure_local_steps():
    """
    Ensures that Chainlit's local_steps ContextVar is initialized to an empty list
    to prevent LookupError crashes during step/message creation.
    """
    from chainlit.context import local_steps
    try:
        local_steps.get()
    except LookupError:
        local_steps.set([])


class SafeStep:
    """
    A wrapper around cl.Step that gracefully handles cases where the
    Chainlit context is lost (e.g., page refresh, websocket blip, or hot-reload).
    """
    def __init__(self, name: str):
        self.name = name
        self.step = None
        ensure_local_steps()
        try:
            from chainlit.context import get_context
            get_context()
            self.step = cl.Step(name=name)
        except Exception:
            logger.debug(f"No Chainlit context for step '{name}'. UI updates for this step will be skipped.")

    async def send(self):
        if self.step:
            try:
                await self.step.send()
            except Exception as e:
                logger.debug(f"Failed to send step '{self.name}': {e}")
                self.step = None

    async def update(self):
        if self.step:
            try:
                await self.step.update()
            except Exception as e:
                logger.debug(f"Failed to update step '{self.name}': {e}")
                self.step = None

    @property
    def output(self):
        return self.step.output if self.step else ""

    @output.setter
    def output(self, val):
        if self.step:
            self.step.output = val

    @property
    def input(self):
        return self.step.input if self.step else ""

    @input.setter
    def input(self, val):
        if self.step:
            self.step.input = val


async def safe_send_message(content: str):
    """
    Gracefully sends a message to the UI or logs to console if context is lost.
    """
    ensure_local_steps()
    try:
        from chainlit.context import get_context
        get_context()
        await cl.Message(content=content).send()
    except Exception:
        logger.info(f"[UI Message Fallback]\n{content}")



def read_workspace_files(base_dir: Path) -> Dict[str, str]:
    """
    Recursively scans the workspace directory and reads all text files.
    """
    files = {}
    if not base_dir.exists():
        return files
        
    for root, dirs, filenames in os.walk(base_dir):
        # Prune directories to skip in-place
        dirs[:] = [d for d in dirs if d not in (".git", "__pycache__", ".venv", "venv", "node_modules", "dist", "build")]
        for filename in filenames:
            # Skip common binary/compiled extensions
            if filename.endswith(('.pyc', '.pyo', '.pyd', '.db', '.png', '.jpg', '.jpeg', '.gif', '.ico', '.zip', '.tar.gz', '.tar', '.pdf', '.svg')):
                continue
            file_path = os.path.join(root, filename)
            rel_path = os.path.relpath(file_path, base_dir)
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    files[rel_path] = f.read()
            except Exception:
                pass
    return files


def write_files_to_workspace(base_dir: Path, files: List[Dict[str, str]]):
    """
    Writes or updates files inside the workspace, sanitizing path prefixes.
    """
    for file_info in files:
        raw_path = file_info["path"]
        rel_path = raw_path
        
        # Sanitize rel_path
        rel_path = rel_path.replace("\\", "/")
        while rel_path.startswith("/"):
            rel_path = rel_path[1:]
            
        prefixes = ["workspace/generated_project/", "generated_project/", "workspace/"]
        for prefix in prefixes:
            if rel_path.startswith(prefix):
                rel_path = rel_path[len(prefix):]
                break
                
        # Save back the sanitized path so downstream reviews/logs use the correct path
        file_info["path"] = rel_path
        
        # If the path ends with a slash, it's a directory. Create it and skip writing.
        if raw_path.replace("\\", "/").endswith("/"):
            dir_path = base_dir / rel_path
            # If a file exists at the directory path, remove it
            if dir_path.exists() and dir_path.is_file():
                dir_path.unlink()
            dir_path.mkdir(parents=True, exist_ok=True)
            continue
            
        content = file_info["content"]
        full_path = base_dir / rel_path
        
        # If the parent path exists but is a file, remove it to allow directory creation
        if full_path.parent.exists() and full_path.parent.is_file():
            logger.warning(f"Parent path {full_path.parent} exists but is a file. Removing it to create directory.")
            full_path.parent.unlink()
            
        full_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(content)


@cl.on_chat_start
async def start():
    ensure_local_steps()
    # Store agents and managers in the user session
    cl.user_session.set("req_agent", RequirementAgent())
    cl.user_session.set("planner_agent", PlannerAgent())
    cl.user_session.set("writer_agent", WriterAgent())
    cl.user_session.set("reviewer_agent", ReviewerAgent())
    cl.user_session.set("validation_agent", ValidationAgent())
    cl.user_session.set("replanner_agent", ReplannerAgent())
    cl.user_session.set("condenser_agent", PromptCondenserAgent())
    cl.user_session.set("task_manager", TaskManager())
    cl.user_session.set("executor", ExecutionRunner())

    await cl.Message(
        content="Welcome to the **AI Coding System**! 🚀\n\nDescribe the application you want to build, and I will autonomously analyze requirements, plan the tasks, write the code, review it, execute/test it, and iterate until it's done!"
    ).send()


@cl.on_message
async def main(message: cl.Message):
    ensure_local_steps()
    req_agent = cl.user_session.get("req_agent") or RequirementAgent()
    planner_agent = cl.user_session.get("planner_agent") or PlannerAgent()
    writer_agent = cl.user_session.get("writer_agent") or WriterAgent()
    reviewer_agent = cl.user_session.get("reviewer_agent") or ReviewerAgent()
    validation_agent = cl.user_session.get("validation_agent") or ValidationAgent()
    replanner_agent = cl.user_session.get("replanner_agent") or ReplannerAgent()
    condenser_agent = cl.user_session.get("condenser_agent") or PromptCondenserAgent()
    task_manager = cl.user_session.get("task_manager") or TaskManager()
    executor = cl.user_session.get("executor") or ExecutionRunner()

    # Save back to session
    cl.user_session.set("req_agent", req_agent)
    cl.user_session.set("planner_agent", planner_agent)
    cl.user_session.set("writer_agent", writer_agent)
    cl.user_session.set("reviewer_agent", reviewer_agent)
    cl.user_session.set("validation_agent", validation_agent)
    cl.user_session.set("replanner_agent", replanner_agent)
    cl.user_session.set("condenser_agent", condenser_agent)
    cl.user_session.set("task_manager", task_manager)
    cl.user_session.set("executor", executor)

    user_prompt = message.content.strip()

    # Token tracking
    token_tracker = {"input": 0, "output": 0, "tasks": {}}

    def record_tokens(agent, label: str, task_id: str = None) -> str:
        usage = getattr(agent, "last_usage", {})
        in_t = usage.get("input_tokens", 0)
        out_t = usage.get("output_tokens", 0)
        tot_t = usage.get("total_tokens", 0)
        
        token_tracker["input"] += in_t
        token_tracker["output"] += out_t
        
        if task_id:
            if task_id not in token_tracker["tasks"]:
                token_tracker["tasks"][task_id] = {"input": 0, "output": 0}
            token_tracker["tasks"][task_id]["input"] += in_t
            token_tracker["tasks"][task_id]["output"] += out_t
            
        logger.info(f"[Tokens] {label} consumed: {tot_t} (Prompt: {in_t}, Completion: {out_t})")
        return f"\n\n*Token usage: {tot_t} tokens (Prompt: {in_t}, Completion: {out_t})*"

    # Condense prompt if it is extremely large to avoid token limits
    if len(user_prompt) > 1500:
        condense_step = SafeStep(name="Prompt Condenser Agent")
        await condense_step.send()
        condense_step.input = f"Extremely large user prompt detected: {len(user_prompt)} characters."
        
        try:
            logger.info("Running Prompt Condenser Agent...")
            condensed_res = condenser_agent.condense(user_prompt)
            token_msg = record_tokens(condenser_agent, "Prompt Condensation")
            
            user_prompt = condensed_res.get("condensed_prompt", user_prompt)
            summary = condensed_res.get("summary", "Summarized request")
            
            condense_step.output = (
                f"### Large input summarized to prevent rate limits\n"
                f"**Extracted Goal**: {summary}\n"
                f"**Condensed Prompt Size**: {len(user_prompt)} characters.{token_msg}"
            )
            await condense_step.update()
            
            # Print condensed prompt summary to screen
            await safe_send_message(f"🔍 **Large input condensed for token efficiency:**\n- **Extracted Goal**: {summary}\n- **Prompt Size**: Reduced to {len(user_prompt)} characters.")
        except Exception as e:
            logger.error(f"Failed to condense prompt: {e}")
            condense_step.output = f"Failed to condense prompt: {e}. Proceeding with original prompt."
            await condense_step.update()

    # Step 1: Requirement Analysis
    spec_step = SafeStep(name="Requirement Analysis Agent")
    await spec_step.send()
    spec_step.input = user_prompt
    logger.info("Starting Requirement Analysis...")
    try:
        specification = req_agent.analyze(user_prompt)
        token_msg = record_tokens(req_agent, "Requirement Analysis")
        spec_step.output = f"### Project Specification Generated:\n\n{specification}{token_msg}"
        await spec_step.update()
        logger.info("Requirement Analysis completed successfully.")
    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"Error during requirement analysis:\n{tb}")
        spec_step.output = f"### Error during requirement analysis:\n```python\n{tb}\n```"
        await spec_step.update()
        await safe_send_message(f"❌ Failed to analyze requirements: {e}")
        return

    # Print spec to main screen
    await safe_send_message(f"📋 **Project Specification Generated**\n\n{specification}")

    # Step 2: Planning
    plan_step = SafeStep(name="Planning Agent")
    await plan_step.send()
    plan_step.input = "Generating implementation plan..."
    logger.info("Starting planning phase...")
    try:
        tasks_list = planner_agent.plan(specification)
        token_msg = record_tokens(planner_agent, "Planning Phase")
        logger.info(f"Generated {len(tasks_list)} tasks from planner.")
        
        # Populate Task Manager
        task_manager.clear()
        task_table = "| Task ID | Title | Description | Expected Files | Dependencies |\n|---|---|---|---|---|\n"
        for t in tasks_list:
            task = Task(
                task_id=t["id"],
                title=t["title"],
                description=t["description"],
                dependencies=t.get("dependencies", []),
                expected_files=t.get("expected_files", [])
            )
            # Carry over custom command if provided
            if "command" in t:
                task.command = t["command"]
            else:
                task.command = ""
            task_manager.add_task(task)
            
            deps_str = ", ".join(t.get("dependencies", [])) or "None"
            files_str = ", ".join(t.get("expected_files", [])) or "None"
            task_table += f"| {t['id']} | {t['title']} | {t['description']} | `{files_str}` | {deps_str} |\n"

        plan_step.output = f"### Development Roadmap:\n\n{task_table}{token_msg}"
        await plan_step.update()
        logger.info("Planning completed successfully.")
    except Exception as e:
        tb = traceback.format_exc()
        logger.error(f"Error during planning:\n{tb}")
        plan_step.output = f"### Error during planning:\n```python\n{tb}\n```"
        await plan_step.update()
        await safe_send_message(f"❌ Failed to generate planning tasks: {e}")
        return

    # Print tasks to main screen
    await safe_send_message(f"🗺️ **Development Roadmap Created**\n\n{task_table}")

    # Step 3: Execution Loop
    loop_step = SafeStep(name="Execution Loop")
    await loop_step.send()
    
    max_task_retries = 3
    
    while True:
        # Pacing: Sleep for a brief moment to avoid rate limit spamming
        await asyncio.sleep(2.0)
        
        task = task_manager.get_next_ready_task()
        if not task:
            # Check if all completed or if there's any pending/failed
            if task_manager.is_all_completed():
                break
            elif task_manager.has_failures():
                loop_step.output = "Execution loop stopped due to task failure."
                await loop_step.update()
                await safe_send_message("⚠️ Execution halted. Some tasks failed and could not be resolved by the Replanning Agent.")
                return
            else:
                # Circular dependencies or no ready tasks but not finished
                loop_step.output = "Execution loop stopped: unresolved task states or circular dependencies."
                await loop_step.update()
                await safe_send_message("⚠️ Execution halted. Unresolved task dependencies detected.")
                return

        # Start Task
        task_manager.update_task_status(task.id, TaskStatus.IN_PROGRESS)
        
        task_run_step = SafeStep(name=f"Task: {task.title} ({task.id})")
        await task_run_step.send()
        task_run_step.input = f"Starting task implementation...\nDescription: {task.description}"
        
        task_completed = False
        writer_feedback = ""
        
        logger.info(f"Executing task: {task.title} ({task.id})")
        while task.retry_count < max_task_retries:
            # Substep A: Code Writer
            logger.info(f"Invoking Code Writer for {task.id} (Attempt {task.retry_count + 1})...")
            writer_step = SafeStep(name=f"Code Writer ({task.id} - Attempt {task.retry_count + 1})")
            await writer_step.send()
            
            try:
                # Read all current workspace files for context
                all_workspace_files = read_workspace_files(GENERATED_PROJECT_DIR)
                
                # Filter to only relevant files for this task to reduce prompt tokens
                relevant_paths = set()
                
                def clean_path_relative(p: str) -> str:
                    p = p.replace("\\", "/")
                    for prefix in ["workspace/generated_project/", "generated_project/", "workspace/"]:
                        if p.startswith(prefix):
                            p = p[len(prefix):]
                            break
                    while p.startswith("/"):
                        p = p[1:]
                    return p
                
                # 1. Expected files for current task
                for f in task.expected_files:
                    relevant_paths.add(clean_path_relative(f))
                    
                # 2. Expected files from dependent tasks
                for dep_id in task.dependencies:
                    dep_task = task_manager.get_task(dep_id)
                    if dep_task:
                        for f in dep_task.expected_files:
                            relevant_paths.add(clean_path_relative(f))
                            
                # 3. Always allow package requirements or setup files if they exist
                relevant_paths.add("requirements.txt")
                relevant_paths.add("setup.py")
                
                existing_files = {}
                for path, content in all_workspace_files.items():
                    cleaned_p = clean_path_relative(path)
                    if cleaned_p in relevant_paths:
                        existing_files[path] = content
                        
                logger.info(f"Task context filtered: sending {len(existing_files)}/{len(all_workspace_files)} files to Writer Agent.")
                
                # Setup task dict for writer input
                task_dict = task.to_dict(clean=True)
                # Ensure writer gets command too
                task_dict["command"] = getattr(task, "command", "")
                
                writer_res = writer_agent.write_code(
                    specification=specification,
                    task=task_dict,
                    existing_files=existing_files,
                    feedback=writer_feedback
                )
                
                # Write files
                files_written = writer_res.get("files", [])
                write_files_to_workspace(GENERATED_PROJECT_DIR, files_written)
                
                paths_written = [f["path"] for f in files_written]
                logger.info(f"Code Writer wrote files: {paths_written}")
                
                # Format files written in markdown with code content
                written_files_markdown = f"### Code written successfully to files: `{', '.join(paths_written)}`\n\n"
                for f in files_written:
                    ext = Path(f["path"]).suffix.lstrip('.') or "txt"
                    written_files_markdown += f"#### `{f['path']}`\n```{ext}\n{f['content']}\n```\n\n"
                
                token_msg = record_tokens(writer_agent, f"Code Writer Attempt {task.retry_count + 1}", task.id)
                writer_step.output = written_files_markdown + token_msg
                task.add_log(f"Code Writer wrote files: {paths_written}")
                await writer_step.update()
                
            except Exception as e:
                tb = traceback.format_exc()
                logger.error(f"Code Writer encountered an error on {task.id}:\n{tb}")
                writer_step.output = f"### Code Writer Error:\n```python\n{tb}\n```"
                await writer_step.update()
                task.add_log(f"Code Writer Error: {e}")
                writer_feedback = f"Writer Error: {e}"
                task.retry_count += 1
                continue

            # Pacing delay to avoid rate limit spamming
            await asyncio.sleep(2.0)

            # Substep B: Code Review
            logger.info(f"Invoking Code Reviewer for task {task.id}...")
            reviewer_step = SafeStep(name=f"Code Reviewer ({task.id})")
            await reviewer_step.send()
            reviewer_step.input = f"Reviewing the following files: {', '.join(paths_written)}"
            
            try:
                # Get content of files written/modified for reviewer
                modified_files_content = {}
                for f in files_written:
                    rel_p = f["path"]
                    full_p = GENERATED_PROJECT_DIR / rel_p
                    if full_p.exists():
                        with open(full_p, "r", encoding="utf-8") as rf:
                            modified_files_content[rel_p] = rf.read()
                            
                review_res = reviewer_agent.review(
                    specification=specification,
                    task=task.to_dict(clean=True),
                    modified_files=modified_files_content
                )
                
                approved = review_res.get("approved", False)
                feedback = review_res.get("feedback", "")
                
                logger.info(f"Code Reviewer completed. Approved: {approved}")
                token_msg = record_tokens(reviewer_agent, f"Code Reviewer {task.id}", task.id)
                reviewer_step.output = f"**Approved**: {approved}\n\n**Feedback**:\n{feedback}{token_msg}"
                await reviewer_step.update()
                task.add_log(f"Code Review: Approved={approved}. Feedback: {feedback}")
                
                if not approved:
                    # Request rework from writer without execution yet
                    writer_feedback = f"Code Review Feedback:\n{feedback}"
                    task.retry_count += 1
                    continue
                    
            except Exception as e:
                tb = traceback.format_exc()
                logger.error(f"Code Reviewer encountered an error on {task.id}:\n{tb}")
                reviewer_step.output = f"### Code Reviewer Error:\n```python\n{tb}\n```"
                await reviewer_step.update()
                task.add_log(f"Code Review Error: {e}")
                # Log error and continue to execution anyway if reviewer fails
                approved = True

            # Substep C: Execution (Build & Test)
            execution_step = SafeStep(name=f"Execution Agent ({task.id})")
            await execution_step.send()
            
            exec_command = getattr(task, "command", "")
            if exec_command:
                # Sanitize to make sure the command doesn't use prefix directories
                exec_command = exec_command.replace("workspace/generated_project/", "")
                exec_command = exec_command.replace("generated_project/", "")
                task.command = exec_command
            else:
                # Attempt to run a sensible default (e.g. pycompile or test)
                if any(f.endswith("_test.py") or f.startswith("test_") for f in task.expected_files):
                    exec_command = "pytest"
                elif any(f.endswith(".py") for f in task.expected_files):
                    # Compile check Python files
                    py_files = [f for f in task.expected_files if f.endswith(".py")]
                    # Ensure py_files paths are sanitized too
                    clean_py_files = []
                    for f in py_files:
                        clean_f = f.replace("workspace/generated_project/", "").replace("generated_project/", "")
                        clean_py_files.append(clean_f)
                    exec_command = f"python3 -m py_compile {' '.join(clean_py_files)}"
                else:
                    exec_command = ""

            if exec_command:
                logger.info(f"Running command: {exec_command}")
                execution_step.input = f"Running command: `{exec_command}`"
                exec_res = executor.execute(exec_command)
                logger.info(f"Command exit code: {exec_res.returncode}")
                task.add_log(f"Executed: `{exec_command}`. Exit Code: {exec_res.returncode}")
                
                output_str = f"**Command**: `{exec_command}`\n**Exit Code**: {exec_res.returncode}\n"
                if exec_res.stdout:
                    output_str += f"**Stdout**:\n```\n{exec_res.stdout}\n```\n"
                if exec_res.stderr:
                    output_str += f"**Stderr**:\n```\n{exec_res.stderr}\n```\n"
                    
                execution_step.output = output_str
                await execution_step.update()
                
                execution_logs = [exec_res.to_dict()]
            else:
                logger.info("No execution command specified or needed for this task.")
                execution_step.output = "No execution command specified or needed for this task."
                await execution_step.update()
                execution_logs = []

            # Pacing delay to avoid rate limit spamming
            await asyncio.sleep(2.0)

            # Substep D: Validation
            logger.info(f"Invoking Validation Agent for task {task.id}...")
            validation_step = SafeStep(name=f"Validation Agent ({task.id})")
            await validation_step.send()
            validation_step.input = f"Validating outputs against specification criteria. Task files: {task.expected_files}"
            
            try:
                val_res = validation_agent.validate(
                    specification=specification,
                    task=task.to_dict(clean=True),
                    execution_logs=execution_logs
                )
                
                success = val_res.get("success", False)
                val_feedback = val_res.get("feedback", "")
                
                logger.info(f"Validation finished. Success: {success}")
                token_msg = record_tokens(validation_agent, f"Validation Agent {task.id}", task.id)
                validation_step.output = f"**Success**: {success}\n\n**Validation Feedback**:\n{val_feedback}{token_msg}"
                await validation_step.update()
                task.add_log(f"Validation: Success={success}. Feedback: {val_feedback}")
                
                if success:
                    task_manager.update_task_status(task.id, TaskStatus.COMPLETED)
                    task_completed = True
                    
                    task_tokens = token_tracker["tasks"].get(task.id, {"input": 0, "output": 0})
                    tot_task_tokens = task_tokens["input"] + task_tokens["output"]
                    
                    task_run_step.output = (
                        f"✅ Task `{task.id}` completed successfully!\n\n"
                        f"*Total task token usage: {tot_task_tokens} tokens "
                        f"(Prompt: {task_tokens['input']}, Completion: {task_tokens['output']})*"
                    )
                    await task_run_step.update()
                    logger.info(f"Task {task.id} completed successfully.")
                    break
                else:
                    # Task failed validation, trigger replanner
                    logger.warning(f"Task {task.id} failed validation. Invoking Replanning Agent...")
                    task_manager.update_task_status(task.id, TaskStatus.FAILED)
                    task.error_feedback = val_feedback
                    
                    # Pacing delay to avoid rate limit spamming
                    await asyncio.sleep(2.0)

                    replanner_step = SafeStep(name=f"Replanning Agent ({task.id})")
                    await replanner_step.send()
                    replanner_step.input = f"Analyzing error log and replanning task {task.id}..."
                    
                    # Fetch remaining tasks (excluding completed and current)
                    remaining = [t.to_dict(clean=True) for t in task_manager.get_all_tasks() if t.status not in (TaskStatus.COMPLETED, TaskStatus.IN_PROGRESS)]
                    
                    replan_res = replanner_agent.replan(
                        specification=specification,
                        failed_task=task.to_dict(clean=True),
                        remaining_tasks=remaining
                    )
                    
                    instructions = replan_res.get("instructions", "")
                    token_msg = record_tokens(replanner_agent, f"Replanning Agent {task.id}", task.id)
                    replanner_step.output = f"### Replanning Guidance:\n\n{instructions}{token_msg}"
                    await replanner_step.update()
                    task.add_log(f"Replanning Guidance: {instructions}")
                    
                    # Set up writer feedback for retry loop
                    writer_feedback = f"Validation Failed. Replanning Guidance:\n{instructions}"
                    task.status = TaskStatus.REPLANNED
                    task.retry_count += 1
                    
            except Exception as e:
                tb = traceback.format_exc()
                logger.error(f"Validation Agent encountered an error on {task.id}:\n{tb}")
                validation_step.output = f"### Validation Agent Error:\n```python\n{tb}\n```"
                await validation_step.update()
                task.add_log(f"Validation Error: {e}")
                # Fallback to failing task and retrying
                task_manager.update_task_status(task.id, TaskStatus.FAILED)
                task.retry_count += 1
                writer_feedback = f"Validation Error: {e}"

        # If loop finished but task not completed, mark it failed and exit loop
        if not task_completed:
            task_manager.update_task_status(task.id, TaskStatus.FAILED)
            task_run_step.output = f"❌ Task `{task.id}` failed after reaching maximum retries ({max_task_retries})."
            await task_run_step.update()
            break

    # Step 4: Display final output
    if task_manager.is_all_completed():
        loop_step.output = "All tasks executed successfully!"
        await loop_step.update()
        
        final_files = read_workspace_files(GENERATED_PROJECT_DIR)
        file_list_markdown = ""
        for path in final_files.keys():
            file_list_markdown += f"- `{path}`\n"
            
        # Build token usage summary for the user
        global_tot = token_tracker["input"] + token_tracker["output"]
        token_summary = (
            f"\n\n📊 **Total Token Usage for this project:**\n"
            f"- **Total Tokens**: {global_tot}\n"
            f"- **Prompt Tokens (Input)**: {token_tracker['input']}\n"
            f"- **Completion Tokens (Output)**: {token_tracker['output']}\n\n"
            f"**Token Usage per Task:**\n"
        )
        for t_id, t_usage in token_tracker["tasks"].items():
            t_tot = t_usage["input"] + t_usage["output"]
            token_summary += f"- **Task {t_id}**: {t_tot} tokens (In: {t_usage['input']}, Out: {t_usage['output']})\n"

        await safe_send_message(f"🎉 **Application Built Successfully!**\n\nThe entire development lifecycle completed autonomously. Here are the generated files inside `workspace/generated_project/`:\n\n{file_list_markdown}{token_summary}\n\nYou can run and test the application directly inside the workspace directory!")
    else:
        # Build token usage summary for failed project
        global_tot = token_tracker["input"] + token_tracker["output"]
        token_summary = (
            f"\n\n📊 **Total Token Usage (before failure):**\n"
            f"- **Total Tokens**: {global_tot}\n"
            f"- **Prompt Tokens (Input)**: {token_tracker['input']}\n"
            f"- **Completion Tokens (Output)**: {token_tracker['output']}\n"
        )
        await safe_send_message(f"⚠️ **Development Loop Stopped**\n\nOne or more tasks failed to complete successfully. Check the execution steps above for logs and error details.{token_summary}")
