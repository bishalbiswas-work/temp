import os
import threading
import time
from pathlib import Path
from dotenv import load_dotenv
from typing import Any, List, Optional, Dict
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import BaseMessage, AIMessage, HumanMessage, SystemMessage
from langchain_core.outputs import ChatResult, ChatGeneration

# Load environment variables from .env
load_dotenv()

# Project Paths
ROOT_DIR = Path(__file__).resolve().parent.parent
WORKSPACE_DIR = ROOT_DIR / "workspace"
GENERATED_PROJECT_DIR = WORKSPACE_DIR / "generated_project"

# Ensure directories exist
WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)
GENERATED_PROJECT_DIR.mkdir(parents=True, exist_ok=True)

# LLM Configuration
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
ZAI_API_KEY = os.getenv("ZAI_API_KEY")

# Global locks and variables to guarantee strictly sequential execution for Z.AI
_zai_lock = threading.Lock()
_last_zai_request_time = 0.0

def call_zai_api(
    model_name: str,
    messages: list,
    temperature: float = 0.0,
    api_key: str = None
) -> dict:
    """
    Centralized mechanism for sending chat completions requests to the Z.AI REST API.
    Guarantees thread-safe, strictly sequential processing, enforces cooldown pacing,
    and logs all requests/responses.
    """
    global _last_zai_request_time
    
    import requests
    
    key = api_key or os.getenv("ZAI_API_KEY")
    if not key:
        raise ValueError("ZAI_API_KEY not found in environment or parameters.")
        
    url = "https://api.z.ai/api/paas/v4/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {key}"
    }
    payload = {
        "model": model_name,
        "messages": messages,
        "temperature": temperature
    }
    
    import logging
    logger = logging.getLogger("AICodingSystem")
    
    with _zai_lock:
        # Enforce sequential cooling-off period of 10.0 seconds between request completions
        elapsed = time.time() - _last_zai_request_time
        if elapsed < 10.0:
            sleep_time = 10.0 - elapsed
            logger.info(f"[Z.AI Cooldown] Sleeping for {sleep_time:.2f}s to guarantee strictly sequential execution.")
            time.sleep(sleep_time)
            
        try:
            logger.info(f"[Z.AI Central API] POST request to {url} (model: {model_name})")
            response = requests.post(url, headers=headers, json=payload, timeout=120)
            
            # Update last request completion time
            _last_zai_request_time = time.time()
            
            logger.info(f"[Z.AI Central API] HTTP response code: {response.status_code}")
            
            if response.status_code != 200:
                try:
                    err_json = response.json()
                except Exception:
                    err_json = response.text
                raise RuntimeError(f"Z.AI API error ({response.status_code}): {err_json}")
                
            return response.json()
            
        except Exception as e:
            # Enforce update of time even on failure so retry backoffs work
            _last_zai_request_time = time.time()
            raise e

class ChatZai(BaseChatModel):
    model_name: str = "glm-4.7-flash"
    temperature: float = 0.0
    api_key: str = ""
    _client: Any = None

    def __init__(self, api_key: str, model_name: str = "glm-4.7-flash", temperature: float = 0.0, **kwargs):
        super().__init__(
            model_name=model_name,
            temperature=temperature,
            api_key=api_key,
            **kwargs
        )
        # Pre-existing code making direct SDK client requests has been commented out:
        # from zai import ZaiClient
        # try:
        #     object.__setattr__(self, "_client", ZaiClient(api_key=api_key, max_retries=0))
        # except TypeError:
        #     object.__setattr__(self, "_client", ZaiClient(api_key=api_key))

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[Any] = None,
        **kwargs: Any,
    ) -> ChatResult:
        zai_messages = []
        for msg in messages:
            if isinstance(msg, SystemMessage):
                role = "system"
            elif isinstance(msg, HumanMessage):
                role = "user"
            elif isinstance(msg, AIMessage):
                role = "assistant"
            else:
                role = "user"
            zai_messages.append({"role": role, "content": msg.content})
            
        # Call the centralized REST API mechanism
        response_json = call_zai_api(
            model_name=self.model_name,
            messages=zai_messages,
            temperature=self.temperature,
            api_key=self.api_key
        )
        
        content = response_json["choices"][0]["message"]["content"]
        
        # Capture usage data
        usage = response_json.get("usage", {})
        usage_metadata = {}
        if usage:
            usage_metadata = {
                "input_tokens": usage.get("prompt_tokens", 0),
                "output_tokens": usage.get("completion_tokens", 0),
                "total_tokens": usage.get("total_tokens", 0)
            }
            
        ai_msg = AIMessage(content=content)
        ai_msg.usage_metadata = usage_metadata
        
        return ChatResult(generations=[ChatGeneration(message=ai_msg)])

    @property
    def _llm_type(self) -> str:
        return "zai"

def get_llm(model_name: str = None, temperature: float = 0.0):
    """
    Initialize and return the appropriate Chat model (Groq or Z.AI).
    """
    selected_model = model_name or GROQ_MODEL
    
    # Check if model selection points to Z.AI (glm models)
    if selected_model.startswith("glm-") or selected_model.startswith("groq/glm-") or os.getenv("AI_PROVIDER") == "zai":
        clean_model = selected_model
        if clean_model.startswith("groq/"):
            clean_model = clean_model.replace("groq/", "", 1)
            
        zai_key = ZAI_API_KEY or os.getenv("ZAI_API_KEY")
        if not zai_key:
            raise ValueError("ZAI_API_KEY environment variable is not set but GLM model was requested.")
            
        return ChatZai(
            api_key=zai_key,
            model_name=clean_model,
            temperature=temperature
        )
        
    from langchain_groq import ChatGroq
    
    kwargs = {
        "api_key": GROQ_API_KEY,
        "model_name": selected_model,
        "temperature": temperature,
    }
    
    # Configure groq/compound custom parameters
    if selected_model == "groq/compound":
        kwargs["model_kwargs"] = {
            "compound_custom": {
                "tools": {
                    "enabled_tools": ["web_search", "code_interpreter", "visit_website"]
                }
            }
        }
    else:
        # Standard models: clean up model name prefix if present
        if selected_model.startswith("groq/"):
            selected_model = selected_model.replace("groq/", "", 1)
        kwargs["model_name"] = selected_model
        
    return ChatGroq(**kwargs)
