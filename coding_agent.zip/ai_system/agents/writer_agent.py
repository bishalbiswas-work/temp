from typing import Dict, Any, List
from ai_system.agents.base import BaseAgent

WRITER_SYSTEM_PROMPT = """You are a highly competent Code Writer Agent.
Your job is to implement code for the current task inside the project directory.

You will receive:
1. The project specification.
2. The current task details.
3. The existing file contents in the workspace (if any).
4. Error feedback or review comments if this is a correction cycle.

You must generate the complete code for the files you need to create or modify.
Your output must be strictly a JSON object with a single key "files", which maps to an array of file objects.
Each file object must contain:
1. "path": The relative path to the file from the workspace root (e.g. "main.py", "tests/test_main.py").
   CRITICAL: Do NOT prefix paths with "workspace/", "generated_project/", or "workspace/generated_project/". All paths must be relative to the workspace root directly (e.g. use "main.py" instead of "workspace/generated_project/main.py").
2. "content": The exact, complete code content to write to that file. Do not use placeholders or omit existing code unless replacing it.

Example JSON output:
{
  "files": [
    {
      "path": "main.py",
      "content": "def greet():\\n    print(\\"Hello, World!\\")\\n\\nif __name__ == \\"__main__\\":\\n    greet()\\n"
    }
  ]
}

Ensure the output is valid JSON. Include ONLY the JSON block. Do not include extra explanation or conversational text.
"""

class WriterAgent(BaseAgent):
    def __init__(self, model_name: str = None):
        super().__init__(system_prompt=WRITER_SYSTEM_PROMPT, model_name=model_name, temperature=0.1)

    def write_code(
        self,
        specification: str,
        task: Dict[str, Any],
        existing_files: Dict[str, str],
        feedback: str = ""
    ) -> Dict[str, Any]:
        """
        Generates code based on specs, task, existing files, and optional feedback.
        Returns a dict containing the list of files to create/modify.
        """
        # Format existing files into context
        files_context = ""
        if existing_files:
            files_context = "### Existing Files in Workspace:\n"
            for path, content in existing_files.items():
                files_context += f"--- Path: {path} ---\n{content}\n\n"
        else:
            files_context = "### Existing Files in Workspace:\nNo files currently exist."

        prompt = f"""
### Project Specification:
{specification}

### Current Task to Execute:
ID: {task['id']}
Title: {task['title']}
Description: {task['description']}
Expected Files: {task.get('expected_files', [])}

{files_context}
"""
        if feedback:
            prompt += f"\n### Feedback / Errors from Previous Attempt:\n{feedback}\nPlease fix the issues detailed above in this iteration.\n"

        prompt += "\nOutput your JSON response now:"

        response_text = self._call_llm(prompt)
        try:
            parsed = self._parse_json_from_response(response_text)
            if "files" not in parsed:
                raise ValueError("Response JSON does not contain 'files' key.")
            return parsed
        except Exception as e:
            raise ValueError(f"Failed to generate code files JSON: {e}. Raw response was: {response_text}")
