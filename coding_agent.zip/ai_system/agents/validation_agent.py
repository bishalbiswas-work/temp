from typing import Dict, Any, List
from ai_system.agents.base import BaseAgent

VALIDATION_SYSTEM_PROMPT = """You are a Quality Assurance and Validation Agent.
Your job is to check the command outputs and test execution logs to verify if the task satisfies the original requirements and acceptance criteria.

NOTE: If the execution logs show a compile/syntax check command (such as 'python3 -m py_compile ...') and the exit code is 0, this indicates success for compilation. Do not fail the validation just because there is no runtime print output, unless the task description explicitly asks you to verify specific runtime printed output.

You will be given:
1. The project specification and acceptance criteria.
2. The current task details.
3. The execution output logs (stdout, stderr, exit code).

You must output a JSON object containing:
1. "success": A boolean (true if all tests passed and requirements met, false otherwise).
2. "feedback": A markdown string summarizing validation findings, specifying exactly which criteria or tests failed.

Example JSON output:
{
  "success": false,
  "feedback": "### Validation Feedback:\\n- Test `test_user_creation` failed with `AssertionError`. The error log shows it expected status code 201 but got 400.\\n- Functional requirement: User sign up endpoint is not functioning correctly."
}

Ensure the output is strictly valid JSON. Return ONLY the JSON code block.
"""

class ValidationAgent(BaseAgent):
    def __init__(self, model_name: str = None):
        super().__init__(system_prompt=VALIDATION_SYSTEM_PROMPT, model_name=model_name, temperature=0.1)

    def validate(
        self,
        specification: str,
        task: Dict[str, Any],
        execution_logs: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Validates task completion using command execution logs.
        """
        logs_context = "### Execution Logs:\n"
        for i, log in enumerate(execution_logs):
            logs_context += f"--- Execution Run {i+1} ---\n"
            logs_context += f"Command: {log.get('command')}\n"
            logs_context += f"Exit Code: {log.get('returncode')}\n"
            logs_context += f"Stdout:\n{log.get('stdout')}\n"
            logs_context += f"Stderr:\n{log.get('stderr')}\n\n"

        prompt = f"""
### Project Specification:
{specification}

### Task Details:
Title: {task['title']}
Description: {task['description']}

{logs_context}
"""
        response_text = self._call_llm(prompt)
        try:
            return self._parse_json_from_response(response_text)
        except Exception as e:
            raise ValueError(f"Failed to parse validation response: {e}. Raw response was: {response_text}")
        
        
        
