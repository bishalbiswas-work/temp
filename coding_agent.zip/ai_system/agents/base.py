import json
import re
import time
import logging
from typing import Dict, Any, Optional, List
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.messages import SystemMessage, HumanMessage
from ai_system.config import get_llm

logger = logging.getLogger("AICodingSystem.Agent")

class BaseAgent:
    """
    Base class for all agents. Handles LLM communication and text parsing.
    """
    def __init__(self, system_prompt: str, model_name: Optional[str] = None, temperature: float = 0.0):
        self.system_prompt = system_prompt
        self.llm = get_llm(model_name=model_name, temperature=temperature)
        self.last_usage = {}

    def _call_llm(self, user_content: str) -> str:
        """
        Invokes the LLM with the agent's system prompt and user input.
        Handles RateLimitErrors (429) gracefully by retrying with backoff.
        """
        messages = [
            SystemMessage(content=self.system_prompt),
            HumanMessage(content=user_content)
        ]
        
        # Estimate input token size
        total_chars = len(self.system_prompt) + len(user_content)
        est_tokens = int(total_chars / 4.0)
        logger.info(f"[{self.__class__.__name__}] Sending request to AI. Estimated input size: {est_tokens} tokens.")
        
        # Write exact request to prompt log file
        import os
        from pathlib import Path
        try:
            log_dir = Path(__file__).resolve().parent.parent.parent / "workspace" / "prompt_logs"
            log_dir.mkdir(parents=True, exist_ok=True)
            
            # Create a unique filename for this agent request
            class_name = self.__class__.__name__
            timestamp = int(time.time() * 1000)
            log_file = log_dir / f"{timestamp}_{class_name}_request.log"
            
            with open(log_file, "w", encoding="utf-8") as f:
                f.write(f"=== AGENT: {class_name} ===\n")
                f.write(f"=== TIMESTAMP: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())} ===\n\n")
                f.write("--- SYSTEM PROMPT ---\n")
                f.write(self.system_prompt)
                f.write("\n\n--- USER PROMPT ---\n")
                f.write(user_content)
                f.write("\n")
        except Exception as log_err:
            logger.error(f"Failed to write request log: {log_err}")
        
        max_retries = 5
        base_delay = 10.0  # seconds
        
        for attempt in range(max_retries):
            try:
                response = self.llm.invoke(messages)
                self.last_usage = getattr(response, "usage_metadata", None) or {}
                
                # Append response to log file
                try:
                    with open(log_file, "a", encoding="utf-8") as f:
                        f.write("\n--- RESPONSE ---\n")
                        f.write(str(response.content))
                        f.write("\n")
                except Exception as log_err:
                    logger.error(f"Failed to append response log: {log_err}")
                    
                return str(response.content)
            except Exception as e:
                err_msg = str(e)
                is_rate_limit = False
                if "429" in err_msg or "rate_limit_exceeded" in err_msg.lower() or "RateLimitError" in type(e).__name__:
                    is_rate_limit = True
                    
                if is_rate_limit and attempt < max_retries - 1:
                    sleep_time = base_delay * (attempt + 1)
                    logger.warning(
                        f"Rate limit exceeded (429). Retrying agent call in {sleep_time}s "
                        f"(Attempt {attempt + 1}/{max_retries})..."
                    )
                    time.sleep(sleep_time)
                else:
                    raise e

    def _parse_json_from_response(self, text: str) -> Any:
        """
        Finds and parses the first JSON block or object in the LLM response text.
        """
        # Try direct parsing first
        try:
            return json.loads(text.strip())
        except json.JSONDecodeError:
            pass

        # Try to find JSON inside markdown code blocks
        json_pattern = re.compile(r"```json\s*(.*?)\s*```", re.DOTALL)
        match = json_pattern.search(text)
        if match:
            try:
                return json.loads(match.group(1).strip())
            except json.JSONDecodeError:
                pass

        # Try searching for matching curly braces/brackets
        # Find first '{' or '[' and last '}' or ']'
        dict_match = re.search(r"(\{.*\}|\[.*\])", text, re.DOTALL)
        if dict_match:
            try:
                return json.loads(dict_match.group(1).strip())
            except json.JSONDecodeError:
                pass

        raise ValueError(f"Could not parse valid JSON from LLM response:\n{text}")
