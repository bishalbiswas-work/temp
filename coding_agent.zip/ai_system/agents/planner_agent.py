from typing import List, Dict, Any
from ai_system.agents.base import BaseAgent

PLANNER_SYSTEM_PROMPT = """You are a software Architect and Planning Agent.
Your job is to read a project specification and decompose it into an ordered list of tasks.

Each task must be atomic, buildable, and testable.
You must return your output strictly as a JSON array of task objects.

Each task object in the array must contain:
1. "id": A unique identifier (e.g., "task_1", "task_2", "task_3")
2. "title": A short title of the task
3. "description": Detailed description of what to implement, build, or test in this task.
4. "dependencies": List of other task IDs that MUST be completed before starting this task.
5. "expected_files": List of file paths relative to the workspace root that this task will create or modify.
   CRITICAL: Do NOT prefix file paths with "workspace/", "generated_project/", or "workspace/generated_project/". They must be relative to the workspace directly (e.g., "main.py" or "tests/test_main.py").
6. "command": Command to execute to verify or run this task (e.g. "python3 main.py" or "pytest" or "python3 -m py_compile main.py"). If none is needed, use "".
   CRITICAL: Do NOT include project directory prefixes in the command (e.g. use "python3 main.py" instead of "python3 workspace/generated_project/main.py").


Example JSON output format:
[
  {
    "id": "task_1",
    "title": "Setup project files",
    "description": "Create basic boilerplate and main script entrypoint.",
    "dependencies": [],
    "expected_files": ["main.py"],
    "command": "python3 -m py_compile main.py"
  },
  {
    "id": "task_2",
    "title": "Add helper logic",
    "description": "Implement business logic and functions in utils.py.",
    "dependencies": ["task_1"],
    "expected_files": ["utils.py", "main.py"],
    "command": "python3 main.py"
  }
]

Ensure the JSON is well-formed. Return ONLY the JSON code block. Do not include introductory or concluding text.
"""

class PlannerAgent(BaseAgent):
    def __init__(self, model_name: str = None):
        super().__init__(system_prompt=PLANNER_SYSTEM_PROMPT, model_name=model_name, temperature=0.1)

    def plan(self, project_specification: str) -> List[Dict[str, Any]]:
        """
        Translates a project specification into a list of structured task dicts.
        """
        response_text = self._call_llm(f"Generate an implementation plan for this specification:\n\n{project_specification}")
        try:
            parsed_plan = self._parse_json_from_response(response_text)
            if not isinstance(parsed_plan, list):
                raise ValueError("Planner output is not a list of tasks.")
            return parsed_plan
        except Exception as e:
            # Fallback or wrap error
            raise ValueError(f"Failed to generate structured plan: {e}. Raw response was: {response_text}")
        
