from typing import Dict, Any
from ai_system.agents.base import BaseAgent

REVIEWER_SYSTEM_PROMPT = """You are a meticulous Code Review Agent.
Your job is to review changes made to code files in the workspace and identify bugs, code smells, style violations, security issues, or performance issues.

You will be given:
1. The project specification.
2. The current task details.
3. The modified/created code.

You must output a JSON object containing:
1. "approved": A boolean (true if code is clean and complete, false if improvements are required).
2. "feedback": A markdown string describing code quality findings, specific line recommendations, or bugs. Keep feedback constructive and detailed.

Example JSON output:
{
  "approved": false,
  "feedback": "### Issues Found:\\n- In `main.py` line 12: Missing type hints on the function signature.\\n- The database connection is opened but never closed. Use a context manager (with statement)."
}

Ensure the output is strictly valid JSON. Return ONLY the JSON code block.
"""

class ReviewerAgent(BaseAgent):
    def __init__(self, model_name: str = None):
        super().__init__(system_prompt=REVIEWER_SYSTEM_PROMPT, model_name=model_name, temperature=0.1)

    def review(
        self,
        specification: str,
        task: Dict[str, Any],
        modified_files: Dict[str, str]
    ) -> Dict[str, Any]:
        """
        Reviews modified files against the task and specifications.
        Returns approval status and markdown feedback.
        """
        files_context = "### Modified Files:\n"
        for path, content in modified_files.items():
            files_context += f"--- Path: {path} ---\n{content}\n\n"

        prompt = f"""
### Project Specification:
{specification}

### Task Details:
Title: {task['title']}
Description: {task['description']}

{files_context}
"""
        response_text = self._call_llm(prompt)
        try:
            return self._parse_json_from_response(response_text)
        except Exception as e:
            raise ValueError(f"Failed to parse review response: {e}. Raw response was: {response_text}")
        
        
