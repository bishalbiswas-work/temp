from typing import Dict, Any
from ai_system.agents.base import BaseAgent

CONDENSER_SYSTEM_PROMPT = """You are a highly efficient Prompt Condenser Agent.
Your job is to read excessively large user prompts (which may contain massive tracebacks, duplicate logs, or extensive explanations) and summarize them into a clean, concise, high-density instruction set.

You must output a JSON object containing:
1. "summary": A concise overview of the user's objective (what needs to be built or fixed).
2. "technical_details": Critical technical details (like specific error tracebacks, line numbers, packages, Python versions) stripped of redundant lines.
3. "condensed_prompt": A combined, condensed prompt representing the user's request. Keep it clean and under 1,000 tokens.

Example JSON output:
{
  "summary": "Fix local_steps context LookupError on startup in app.py",
  "technical_details": "LookupError: <ContextVar name='local_steps' at 0x106a44d10> inside chainlit/step.py line 440 during message send on chat start.",
  "condensed_prompt": "Fix the following issue:\\nLookupError: <ContextVar name='local_steps' at 0x106a44d10>\\nTraceback shows LookupError in chainlit/step.py line 440 during start() call."
}

Ensure the output is valid JSON. Include ONLY the JSON block.
"""

class PromptCondenserAgent(BaseAgent):
    def __init__(self, model_name: str = None):
        super().__init__(system_prompt=CONDENSER_SYSTEM_PROMPT, model_name=model_name, temperature=0.1)

    def condense(self, raw_prompt: str) -> Dict[str, Any]:
        """
        Condenses a large user prompt to avoid token limit errors.
        """
        response_text = self._call_llm(f"Condense the following raw user prompt:\n\n{raw_prompt}")
        try:
            return self._parse_json_from_response(response_text)
        except Exception as e:
            # Fallback if parsing fails
            return {
                "summary": "User Request",
                "technical_details": "",
                "condensed_prompt": raw_prompt[:4000] # Truncate to safe character length
            }
