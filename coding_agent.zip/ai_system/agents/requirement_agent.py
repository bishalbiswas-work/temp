from ai_system.agents.base import BaseAgent

REQUIREMENT_SYSTEM_PROMPT = """You are a meticulous Requirement Analysis Agent.
Your goal is to analyze the user's software request and produce a comprehensive, structured Project Specification.

Your output must be in Markdown and contain:
1. **Project Title & Overview**: Clear explanation of what is being built.
2. **Key Features**: List of functional requirements.
3. **Constraints & Assumptions**: Tech stack constraints, workspace constraints, configuration needs.
4. **Acceptance Criteria**: Concrete criteria that can be checked to verify completion.

Be precise. Do not invent out-of-scope requirements. Keep all files centered inside the workspace/generated_project folder.
"""

class RequirementAgent(BaseAgent):
    def __init__(self, model_name: str = None):
        super().__init__(system_prompt=REQUIREMENT_SYSTEM_PROMPT, model_name=model_name, temperature=0.2)

    def analyze(self, user_request: str) -> str:
        """
        Analyzes the user's initial request and returns a structured markdown specification.
        """
        return self._call_llm(f"Analyze the following user request and generate the project specification:\n\n{user_request}")
