from typing import Dict, Any, List, Optional
from ai_system.agents.base import BaseAgent

REPLANNER_SYSTEM_PROMPT = """You are a software Troubleshooting and Replanning Agent.
Your job is to analyze execution/validation failures and decide how to recover.

You will be given:
1. The project specification.
2. The task that failed (including its metadata and logs).
3. The remaining tasks in the queue.

You must output a JSON object containing:
1. "instructions": A detailed markdown analysis of what caused the failure and step-by-step instructions on how the Code Writer Agent can fix the issue.
2. "updated_tasks": (Optional) A modified list of the remaining tasks if you need to add, delete, or rearrange tasks to fix the issue (e.g., adding an environment setup task, splitting a complex task). If no changes to the task list structure are needed, return null or omit this field.

Example JSON output:
{
  "instructions": "### Failure Analysis:\\nThe failure is caused by an ImportError because `requests` is not installed.\\n### Recovery Steps:\\n1. Add `requests` to requirements.txt.\\n2. Modify the code to handle connection timeouts.",
  "updated_tasks": null
}

Ensure the output is strictly valid JSON. Return ONLY the JSON code block.
"""

class ReplannerAgent(BaseAgent):
    def __init__(self, model_name: str = None):
        super().__init__(system_prompt=REPLANNER_SYSTEM_PROMPT, model_name=model_name, temperature=0.2)

    def replan(
        self,
        specification: str,
        failed_task: Dict[str, Any],
        remaining_tasks: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Analyzes task failure and provides recovery steps and optional task updates.
        """
        tasks_context = "### Remaining Tasks:\n"
        for task in remaining_tasks:
            tasks_context += f"- {task['id']}: {task['title']} ({task['description']})\n"

        prompt = f"""
### Project Specification:
{specification}

### Failed Task Details:
ID: {failed_task['id']}
Title: {failed_task['title']}
Description: {failed_task['description']}
Error/Feedback: {failed_task.get('error_feedback')}
Logs: {failed_task.get('logs', [])}

{tasks_context}
"""
        response_text = self._call_llm(prompt)
        try:
            return self._parse_json_from_response(response_text)
        except Exception as e:
            raise ValueError(f"Failed to parse replanner response: {e}. Raw response was: {response_text}")
        
        
