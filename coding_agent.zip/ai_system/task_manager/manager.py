from enum import Enum
from typing import List, Dict, Any, Optional

class TaskStatus(str, Enum):
    PENDING = "Pending"
    READY = "Ready"
    IN_PROGRESS = "In Progress"
    COMPLETED = "Completed"
    FAILED = "Failed"
    NEEDS_REVIEW = "Needs Review"
    REPLANNED = "Replanned"


class Task:
    """
    Represents a single atomic task in the software development plan.
    """
    def __init__(
        self,
        task_id: str,
        title: str,
        description: str,
        dependencies: Optional[List[str]] = None,
        expected_files: Optional[List[str]] = None
    ):
        self.id = task_id
        self.title = title
        self.description = description
        self.dependencies = dependencies or []
        self.expected_files = expected_files or []
        self.status = TaskStatus.PENDING
        self.logs: List[str] = []
        self.error_feedback: Optional[str] = None
        self.retry_count = 0

    def add_log(self, log_msg: str):
        self.logs.append(log_msg)

    def to_dict(self, clean: bool = False) -> Dict[str, Any]:
        d = {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "dependencies": self.dependencies,
            "expected_files": self.expected_files,
            "status": self.status.value,
            "error_feedback": self.error_feedback,
            "retry_count": self.retry_count,
        }
        if not clean:
            d["logs"] = self.logs
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Task":
        task = cls(
            task_id=data["id"],
            title=data["title"],
            description=data["description"],
            dependencies=data.get("dependencies", []),
            expected_files=data.get("expected_files", [])
        )
        task.status = TaskStatus(data.get("status", "Pending"))
        task.logs = data.get("logs", [])
        task.error_feedback = data.get("error_feedback")
        task.retry_count = data.get("retry_count", 0)
        return task


class TaskManager:
    """
    Coordinates task scheduling, state progression, and dependency checks.
    """
    def __init__(self):
        self.tasks: Dict[str, Task] = {}

    def add_task(self, task: Task):
        self.tasks[task.id] = task

    def clear(self):
        self.tasks.clear()

    def get_task(self, task_id: str) -> Optional[Task]:
        return self.tasks.get(task_id)

    def get_all_tasks(self) -> List[Task]:
        return list(self.tasks.values())

    def update_task_status(self, task_id: str, status: TaskStatus):
        if task_id in self.tasks:
            self.tasks[task_id].status = status
            # Proactively update overall state (e.g. mark pending tasks as ready if deps resolved)
            self._update_ready_states()

    def _update_ready_states(self):
        """
        Transitions PENDING tasks to READY if all their dependencies are COMPLETED.
        """
        for task in self.tasks.values():
            if task.status == TaskStatus.PENDING:
                deps_met = True
                for dep_id in task.dependencies:
                    dep_task = self.tasks.get(dep_id)
                    if not dep_task or dep_task.status != TaskStatus.COMPLETED:
                        deps_met = False
                        break
                if deps_met:
                    task.status = TaskStatus.READY

    def get_next_ready_task(self) -> Optional[Task]:
        """
        Retrieves the next task that is READY to be processed.
        Prioritizes tasks by ID order (usually chronological).
        """
        # Ensure ready statuses are up to date
        self._update_ready_states()
        
        ready_tasks = [t for t in self.tasks.values() if t.status == TaskStatus.READY]
        if not ready_tasks:
            return None
        # Sort by key/id to maintain deterministic ordering
        return min(ready_tasks, key=lambda t: t.id)

    def is_all_completed(self) -> bool:
        """
        Checks if all tasks are in the COMPLETED state.
        """
        if not self.tasks:
            return False
        return all(t.status == TaskStatus.COMPLETED for t in self.tasks.values())

    def has_failures(self) -> bool:
        """
        Checks if any tasks have failed.
        """
        return any(t.status == TaskStatus.FAILED for t in self.tasks.values())

    def reset_failed_task_for_retry(self, task_id: str, feedback: str):
        """
        Prepares a failed task for replanning/retry.
        """
        task = self.get_task(task_id)
        if task:
            task.status = TaskStatus.REPLANNED
            task.error_feedback = feedback
            task.retry_count += 1
            task.add_log(f"Task replanned. Error encountered: {feedback}")
