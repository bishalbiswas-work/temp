import os
import subprocess
import shlex
from typing import Dict, Any, Optional
from ai_system.config import GENERATED_PROJECT_DIR

class CommandResult:
    """
    Holds the outcome of a subprocess execution.
    """
    def __init__(self, stdout: str, stderr: str, returncode: int, command: str):
        self.stdout = stdout
        self.stderr = stderr
        self.returncode = returncode
        self.command = command

    @property
    def is_success(self) -> bool:
        return self.returncode == 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "command": self.command,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "returncode": self.returncode,
            "is_success": self.is_success,
        }


class ExecutionRunner:
    """
    Responsible for executing terminal commands in the isolated workspace.
    """
    def __init__(self, workspace_dir: str = None):
        self.workspace_dir = workspace_dir or str(GENERATED_PROJECT_DIR)

    def execute(
        self,
        command: str,
        timeout: float = 60.0,
        env_override: Optional[Dict[str, str]] = None
    ) -> CommandResult:
        """
        Executes a shell command inside the workspace directory.
        Sanitizes environment variables to isolate the running process.
        """
        # Parse command if it is a string
        if isinstance(command, str):
            cmd_args = shlex.split(command)
        else:
            cmd_args = command

        # Sanitized environment
        env = os.environ.copy()
        # Remove LLM keys to ensure isolation, unless explicitly overridden
        sensitive_keys = ["GROQ_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY"]
        for key in sensitive_keys:
            if key in env:
                del env[key]

        # Apply any overrides
        if env_override:
            env.update(env_override)

        try:
            # Run the command with timeout and capture output
            result = subprocess.run(
                cmd_args,
                cwd=self.workspace_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=env,
                timeout=timeout
            )
            return CommandResult(
                stdout=result.stdout,
                stderr=result.stderr,
                returncode=result.returncode,
                command=command
            )
        except subprocess.TimeoutExpired as e:
            return CommandResult(
                stdout=e.stdout.decode('utf-8', errors='replace') if e.stdout else "",
                stderr=f"Command timed out after {timeout} seconds. " + (e.stderr.decode('utf-8', errors='replace') if e.stderr else ""),
                returncode=-1,
                command=command
            )
        except Exception as e:
            return CommandResult(
                stdout="",
                stderr=str(e),
                returncode=-1,
                command=command
            )
